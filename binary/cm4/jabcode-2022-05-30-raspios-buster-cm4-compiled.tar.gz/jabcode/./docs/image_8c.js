var image_8c =
[
    [ "readImage", "image_8c.html#afa442823f5dd29df61d7967c24e919b4", null ],
    [ "saveImage", "image_8c.html#a15ee739502a4241ced61243011b896fb", null ]
];