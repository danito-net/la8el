var structjab__metadata =
[
    [ "docked_position", "structjab__metadata.html#a2916ee787fe556c495329baf17a8074e", null ],
    [ "ecl", "structjab__metadata.html#a7647b91da99641a22b76964c280f71a6", null ],
    [ "mask_type", "structjab__metadata.html#a805e532dd23a6fbe34822d23e8a9eeb4", null ],
    [ "Nc", "structjab__metadata.html#a10a4bd8e49da8f5f17644a997724e878", null ],
    [ "side_version", "structjab__metadata.html#a6c929e9975cc6a0701469175828a9b54", null ],
    [ "VF", "structjab__metadata.html#a250c8c933c94ab1ddfe295f504719f8d", null ]
];