var structjab__bitmap =
[
    [ "bits_per_channel", "structjab__bitmap.html#a6f2feadfd167b319cb90b99e3a32e146", null ],
    [ "bits_per_pixel", "structjab__bitmap.html#acf63b236299656a513f61ca3dbe8fc22", null ],
    [ "channel_count", "structjab__bitmap.html#a026e130e0a3b5e4318e166757b90dfa2", null ],
    [ "height", "structjab__bitmap.html#a6cfca4d628eb417a08cd1a165565b1d9", null ],
    [ "pixel", "structjab__bitmap.html#aa9891bd12195ca9b7e20e3da584ce343", null ],
    [ "width", "structjab__bitmap.html#a44438fd093f14d77db1ffb35e2ac227a", null ]
];