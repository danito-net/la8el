var searchData=
[
  ['dimension',['dimension',['../structjab__code.html#a04daaf524594a802de7b7ef2c973bfa0',1,'jab_code']]]
];
