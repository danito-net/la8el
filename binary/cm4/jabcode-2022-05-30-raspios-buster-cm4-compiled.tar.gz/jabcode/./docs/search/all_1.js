var searchData=
[
  ['binarizer',['binarizer',['../binarizer_8c.html#a013cc09bb47faf1bbcedb9c49d17a06d',1,'binarizer(jab_bitmap *bitmap, jab_int32 channel):&#160;binarizer.c'],['../detector_8h.html#a013cc09bb47faf1bbcedb9c49d17a06d',1,'binarizer(jab_bitmap *bitmap, jab_int32 channel):&#160;binarizer.c']]],
  ['binarizer_2ec',['binarizer.c',['../binarizer_8c.html',1,'']]],
  ['binarizerhard',['binarizerHard',['../binarizer_8c.html#a1d1832f2f5252bc30c034627b32672e3',1,'binarizerHard(jab_bitmap *bitmap, jab_int32 channel, jab_int32 threshold):&#160;binarizer.c'],['../detector_8h.html#a1d1832f2f5252bc30c034627b32672e3',1,'binarizerHard(jab_bitmap *bitmap, jab_int32 channel, jab_int32 threshold):&#160;binarizer.c']]],
  ['binarizerhist',['binarizerHist',['../binarizer_8c.html#a8ea25a9964ffe3bd03eb7e8e2489740a',1,'binarizerHist(jab_bitmap *bitmap, jab_int32 channel):&#160;binarizer.c'],['../detector_8h.html#a8ea25a9964ffe3bd03eb7e8e2489740a',1,'binarizerHist(jab_bitmap *bitmap, jab_int32 channel):&#160;binarizer.c']]]
];
