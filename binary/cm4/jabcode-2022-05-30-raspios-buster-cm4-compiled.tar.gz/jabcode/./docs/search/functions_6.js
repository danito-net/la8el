var searchData=
[
  ['gaussjordan',['GaussJordan',['../ldpc_8c.html#a6ebeae6e4a5064ae12586fb5c657a78c',1,'ldpc.c']]],
  ['gencolorpalette',['genColorPalette',['../encoder_8c.html#aec3b2b02a89e0b23b7a2171eefd35270',1,'encoder.c']]],
  ['generatejabcode',['generateJABCode',['../encoder_8c.html#ab20a4419a33deb26aeb0df1767ff8a73',1,'generateJABCode(jab_encode *enc, jab_data *data):&#160;encoder.c'],['../jabcode_8h.html#ab20a4419a33deb26aeb0df1767ff8a73',1,'generateJABCode(jab_encode *enc, jab_data *data):&#160;encoder.c']]],
  ['getbestpattern',['getBestPattern',['../detector_8c.html#a38529b78a5f10dd745dc1d683fa20c5f',1,'detector.c']]],
  ['getbinarybitmap',['getBinaryBitmap',['../binarizer_8c.html#a18bbdbfa0ea7669329a14ad5ff3012bb',1,'binarizer.c']]],
  ['getcodepara',['getCodePara',['../encoder_8c.html#a5baf22c3435baacb44e04170ea194968',1,'encoder.c']]],
  ['getcolorpaletteindex',['getColorPaletteIndex',['../encoder_8c.html#aa30a9a46c686267d6cc53ef26254d78c',1,'encoder.c']]],
  ['getmetadatalength',['getMetadataLength',['../encoder_8c.html#a76d530a4e5358afe940fb39d61c9e7f2',1,'encoder.c']]],
  ['getminimumthreshold',['getMinimumThreshold',['../binarizer_8c.html#ad0a455e77ee2e7cc3adbd0d9f5dfe524',1,'binarizer.c']]],
  ['getnextmetadatamoduleinmaster',['getNextMetadataModuleInMaster',['../encoder_8h.html#a62edb43fc31903ebea79bf4c39ed2edd',1,'getNextMetadataModuleInMaster(jab_int32 matrix_height, jab_int32 matrix_width, jab_int32 next_module_count, jab_int32 *x, jab_int32 *y):&#160;decoder.c'],['../decoder_8h.html#a62edb43fc31903ebea79bf4c39ed2edd',1,'getNextMetadataModuleInMaster(jab_int32 matrix_height, jab_int32 matrix_width, jab_int32 next_module_count, jab_int32 *x, jab_int32 *y):&#160;decoder.c'],['../decoder_8c.html#a62edb43fc31903ebea79bf4c39ed2edd',1,'getNextMetadataModuleInMaster(jab_int32 matrix_height, jab_int32 matrix_width, jab_int32 next_module_count, jab_int32 *x, jab_int32 *y):&#160;decoder.c']]],
  ['getoptimalecc',['getOptimalECC',['../encoder_8c.html#aaf055e8a186070f5594a54bbe47747ce',1,'encoder.c']]],
  ['getpalettethreshold',['getPaletteThreshold',['../decoder_8c.html#ad527eca4cc7d156db44b6a3568155031',1,'decoder.c']]],
  ['getperspectivetransform',['getPerspectiveTransform',['../detector_8h.html#a316e58cb6a2b80e0c2a309850fde051d',1,'getPerspectiveTransform(jab_point p0, jab_point p1, jab_point p2, jab_point p3, jab_vector2d side_size):&#160;transform.c'],['../transform_8c.html#a316e58cb6a2b80e0c2a309850fde051d',1,'getPerspectiveTransform(jab_point p0, jab_point p1, jab_point p2, jab_point p3, jab_vector2d side_size):&#160;transform.c']]],
  ['getsidesize',['getSideSize',['../detector_8c.html#a855895df5a9c8921ced4a773276bcab4',1,'detector.c']]],
  ['getsymbolcapacity',['getSymbolCapacity',['../encoder_8c.html#a56c3b77942f95b93e8b4b863dd5ce91e',1,'encoder.c']]]
];
