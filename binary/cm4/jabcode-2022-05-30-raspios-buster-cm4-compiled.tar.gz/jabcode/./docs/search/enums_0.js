var searchData=
[
  ['jab_5fencode_5fmode',['jab_encode_mode',['../decoder_8h.html#ad2087fa1d31ef255ec1c7c7b794677a9',1,'decoder.h']]]
];
