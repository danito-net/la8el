var searchData=
[
  ['warppoints',['warpPoints',['../detector_8h.html#a2693aa030475b528827bb178db11fbcd',1,'warpPoints(jab_perspective_transform *pt, jab_point *points, jab_int32 length):&#160;transform.c'],['../transform_8c.html#a2693aa030475b528827bb178db11fbcd',1,'warpPoints(jab_perspective_transform *pt, jab_point *points, jab_int32 length):&#160;transform.c']]]
];
