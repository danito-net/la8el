var searchData=
[
  ['updatemastermetadatapartii',['updateMasterMetadataPartII',['../encoder_8c.html#ad4f0f9f8babf7f712bb1b7d41180a141',1,'encoder.c']]],
  ['updateslavemetadatae',['updateSlaveMetadataE',['../encoder_8c.html#a87b9c62d5fb71fb3ca2480ee0842e7ac',1,'encoder.c']]]
];
