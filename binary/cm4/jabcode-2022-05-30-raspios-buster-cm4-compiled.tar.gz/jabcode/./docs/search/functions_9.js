var searchData=
[
  ['maskcode',['maskCode',['../encoder_8h.html#a266feda838ccf5d9844585dbb7fa2953',1,'maskCode(jab_encode *enc, jab_code *cp):&#160;mask.c'],['../mask_8c.html#a266feda838ccf5d9844585dbb7fa2953',1,'maskCode(jab_encode *enc, jab_code *cp):&#160;mask.c']]],
  ['masksymbols',['maskSymbols',['../encoder_8h.html#ab5f641aa7ae503c30fdca2b1a108d0ab',1,'maskSymbols(jab_encode *enc, jab_int32 mask_type, jab_int32 *masked, jab_code *cp):&#160;mask.c'],['../mask_8c.html#ab5f641aa7ae503c30fdca2b1a108d0ab',1,'maskSymbols(jab_encode *enc, jab_int32 mask_type, jab_int32 *masked, jab_code *cp):&#160;mask.c']]],
  ['multiply',['multiply',['../transform_8c.html#acbb98471ada224b76c0a3576363bb073',1,'transform.c']]]
];
