var searchData=
[
  ['binarizer_2ec',['binarizer.c',['../binarizer_8c.html',1,'']]]
];
