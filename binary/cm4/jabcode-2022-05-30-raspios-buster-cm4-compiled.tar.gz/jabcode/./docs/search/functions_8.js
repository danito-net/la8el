var searchData=
[
  ['loaddefaultmastermetadata',['loadDefaultMasterMetadata',['../decoder_8c.html#ac6fda0e1362b309d515103e1b4890a19',1,'decoder.c']]]
];
