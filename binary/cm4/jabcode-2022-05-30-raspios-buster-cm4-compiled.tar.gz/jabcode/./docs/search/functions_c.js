var searchData=
[
  ['rawmoduledata2rawdata',['rawModuleData2RawData',['../decoder_8c.html#ab1f2035c40cf4aa3b6311c51040abd2f',1,'decoder.c']]],
  ['readcolorpaletteinmaster',['readColorPaletteInMaster',['../decoder_8h.html#afb68b61dc813e719103deeabb019f81c',1,'readColorPaletteInMaster(jab_bitmap *matrix, jab_decoded_symbol *symbol, jab_byte *data_map, jab_int32 *module_count, jab_int32 *x, jab_int32 *y):&#160;decoder.c'],['../decoder_8c.html#afb68b61dc813e719103deeabb019f81c',1,'readColorPaletteInMaster(jab_bitmap *matrix, jab_decoded_symbol *symbol, jab_byte *data_map, jab_int32 *module_count, jab_int32 *x, jab_int32 *y):&#160;decoder.c']]],
  ['readcolorpaletteinslave',['readColorPaletteInSlave',['../decoder_8h.html#a3a5388d194d0e536124b666c7cdca1ba',1,'readColorPaletteInSlave(jab_bitmap *matrix, jab_decoded_symbol *symbol, jab_byte *data_map):&#160;decoder.c'],['../decoder_8c.html#a3a5388d194d0e536124b666c7cdca1ba',1,'readColorPaletteInSlave(jab_bitmap *matrix, jab_decoded_symbol *symbol, jab_byte *data_map):&#160;decoder.c']]],
  ['readdata',['readData',['../decoder_8c.html#adba7df85ceeb9225f1048f1a44982ecb',1,'decoder.c']]],
  ['readimage',['readImage',['../image_8c.html#afa442823f5dd29df61d7967c24e919b4',1,'readImage(jab_char *filename):&#160;image.c'],['../jabcode_8h.html#afa442823f5dd29df61d7967c24e919b4',1,'readImage(jab_char *filename):&#160;image.c']]],
  ['readrawmoduledata',['readRawModuleData',['../decoder_8c.html#a066df160a8bfe3b9ab73a718b208b689',1,'decoder.c']]],
  ['removebadpatterns',['removeBadPatterns',['../detector_8c.html#af4fd1dc7da373ec22a3df79be1d9472c',1,'detector.c']]],
  ['reporterror',['reportError',['../encoder_8c.html#af15ce062faa23e134672a80866b41f29',1,'reportError(jab_char *message):&#160;encoder.c'],['../jabcode_8h.html#af15ce062faa23e134672a80866b41f29',1,'reportError(jab_char *message):&#160;encoder.c']]]
];
