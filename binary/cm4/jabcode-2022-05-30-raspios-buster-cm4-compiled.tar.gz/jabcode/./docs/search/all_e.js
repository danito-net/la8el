var searchData=
[
  ['sample_2ec',['sample.c',['../sample_8c.html',1,'']]],
  ['samplecrossarea',['sampleCrossArea',['../sample_8c.html#a74dfd2384abd2574a16bfde7fc0c2dc9',1,'sampleCrossArea(jab_bitmap *bitmap, jab_perspective_transform *pt):&#160;sample.c'],['../detector_8h.html#a74dfd2384abd2574a16bfde7fc0c2dc9',1,'sampleCrossArea(jab_bitmap *bitmap, jab_perspective_transform *pt):&#160;sample.c']]],
  ['samplesymbol',['sampleSymbol',['../sample_8c.html#a6586265f273ba12a50e527914dffcbfe',1,'sampleSymbol(jab_bitmap *bitmap, jab_perspective_transform *pt, jab_vector2d side_size):&#160;sample.c'],['../detector_8h.html#a6586265f273ba12a50e527914dffcbfe',1,'sampleSymbol(jab_bitmap *bitmap, jab_perspective_transform *pt, jab_vector2d side_size):&#160;sample.c']]],
  ['samplesymbolbyalignmentpattern',['sampleSymbolByAlignmentPattern',['../detector_8c.html#a5285f754b18e082f6bf0493df4fdfa2e',1,'detector.c']]],
  ['samplesymbolwithnc',['sampleSymbolwithNc',['../sample_8c.html#a540d63013fbb4a8a247b780b08dd00be',1,'sampleSymbolwithNc(jab_bitmap *bitmap, jab_perspective_transform *pt, jab_vector2d side_size, jab_int32 symbol_type, jab_bitmap *ch[]):&#160;sample.c'],['../detector_8h.html#a540d63013fbb4a8a247b780b08dd00be',1,'sampleSymbolwithNc(jab_bitmap *bitmap, jab_perspective_transform *pt, jab_vector2d side_size, jab_int32 symbol_type, jab_bitmap *ch[]):&#160;sample.c']]],
  ['savealignmentpattern',['saveAlignmentPattern',['../detector_8c.html#afe8a62d0dc9c82c202d30038e3b96357',1,'detector.c']]],
  ['savefinderpattern',['saveFinderPattern',['../detector_8c.html#ae0f80f47530944d1bde36e0192c7fd65',1,'detector.c']]],
  ['saveimage',['saveImage',['../image_8c.html#a15ee739502a4241ced61243011b896fb',1,'saveImage(jab_bitmap *bitmap, jab_char *filename):&#160;image.c'],['../jabcode_8h.html#a15ee739502a4241ced61243011b896fb',1,'saveImage(jab_bitmap *bitmap, jab_char *filename):&#160;image.c']]],
  ['scanpatternvertical',['scanPatternVertical',['../detector_8c.html#aab5c963b34fc039e9218154fbc0bf861',1,'detector.c']]],
  ['seekpattern',['seekPattern',['../detector_8c.html#a958429eafeab47c3391419a6f0921a20',1,'detector.c']]],
  ['seekpatternhorizontal',['seekPatternHorizontal',['../detector_8c.html#a2c6e26778492fd0652215e38ac31a8f0',1,'detector.c']]],
  ['selectbestpatterns',['selectBestPatterns',['../detector_8c.html#a0290bccbb165e2e307a0d5c05e5659f4',1,'detector.c']]],
  ['setdefaultecclevels',['setDefaultEccLevels',['../encoder_8c.html#ab4f467e8c7aaf3a9fb6af0917f3f0f3c',1,'encoder.c']]],
  ['setdefaultpalette',['setDefaultPalette',['../encoder_8c.html#aad6a82cf3e7ee818af8970049c659e83',1,'encoder.c']]],
  ['setmastersymbolversion',['setMasterSymbolVersion',['../encoder_8c.html#ad74e8e9b2fd4cde7ecc87b4c9bceed30',1,'encoder.c']]],
  ['setslavemetadata',['setSlaveMetadata',['../encoder_8c.html#ad6e1f11a3855cf89d35c4c2e82faf362',1,'encoder.c']]],
  ['square2quad',['square2Quad',['../transform_8c.html#ac77b947bf60b1e2ca55137def7b7c87c',1,'transform.c']]],
  ['swap_5fbyte',['swap_byte',['../encoder_8c.html#aec19e494a16d68ca67f7aab6c3dcfb75',1,'encoder.c']]],
  ['swap_5fint',['swap_int',['../encoder_8c.html#a56d758043d2bf9aa41ab23b578c71ed3',1,'encoder.c']]],
  ['swap_5fsymbols',['swap_symbols',['../encoder_8c.html#a0058760eeb0988fabf6af21ffbf93154',1,'encoder.c']]],
  ['symbols',['symbols',['../structjab__encode.html#ae9c2d64f535616b6e0e1b979479f6c17',1,'jab_encode']]]
];
