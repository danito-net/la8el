var searchData=
[
  ['jab_5falignment_5fpattern',['jab_alignment_pattern',['../structjab__alignment__pattern.html',1,'']]],
  ['jab_5fbitmap',['jab_bitmap',['../structjab__bitmap.html',1,'']]],
  ['jab_5fcode',['jab_code',['../structjab__code.html',1,'']]],
  ['jab_5fdata',['jab_data',['../structjab__data.html',1,'']]],
  ['jab_5fdecoded_5fsymbol',['jab_decoded_symbol',['../structjab__decoded__symbol.html',1,'']]],
  ['jab_5fencode',['jab_encode',['../structjab__encode.html',1,'']]],
  ['jab_5fencode_5fmode',['jab_encode_mode',['../decoder_8h.html#ad2087fa1d31ef255ec1c7c7b794677a9',1,'decoder.h']]],
  ['jab_5ffinder_5fpattern',['jab_finder_pattern',['../structjab__finder__pattern.html',1,'']]],
  ['jab_5fmetadata',['jab_metadata',['../structjab__metadata.html',1,'']]],
  ['jab_5fperspective_5ftransform',['jab_perspective_transform',['../structjab__perspective__transform.html',1,'']]],
  ['jab_5fpoint',['jab_point',['../structjab__point.html',1,'']]],
  ['jab_5fsymbol',['jab_symbol',['../structjab__symbol.html',1,'']]],
  ['jab_5fvector2d',['jab_vector2d',['../structjab__vector2d.html',1,'']]],
  ['jabcode_2eh',['jabcode.h',['../jabcode_8h.html',1,'']]]
];
