var searchData=
[
  ['quad2square',['quad2Square',['../transform_8c.html#a80aec2ef5275da968374f0a515002935',1,'transform.c']]]
];
