var searchData=
[
  ['image_2ec',['image.c',['../image_8c.html',1,'']]],
  ['initsymbols',['InitSymbols',['../encoder_8c.html#aee878a902f3c053808f99d19d2f65d6e',1,'encoder.c']]],
  ['interleave_2ec',['interleave.c',['../interleave_8c.html',1,'']]],
  ['interleavedata',['interleaveData',['../encoder_8h.html#aaf334907ef3f3e058472ab9259cb8ff8',1,'interleaveData(jab_data *data):&#160;interleave.c'],['../interleave_8c.html#aaf334907ef3f3e058472ab9259cb8ff8',1,'interleaveData(jab_data *data):&#160;interleave.c']]],
  ['interpolatepalette',['interpolatePalette',['../decoder_8c.html#a98b7c2b8160330f7c7aacffb3c0d1c00',1,'decoder.c']]],
  ['isbitrimodal',['isBiTrimodal',['../binarizer_8c.html#adb4a9dede1b12a5926ac6a40d487c263',1,'binarizer.c']]],
  ['isdefaultmode',['isDefaultMode',['../encoder_8c.html#a742a796ef0908261c9aaedb206bdeae6',1,'encoder.c']]]
];
