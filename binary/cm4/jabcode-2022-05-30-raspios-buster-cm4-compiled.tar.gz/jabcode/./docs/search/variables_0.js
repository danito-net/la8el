var searchData=
[
  ['code_5fsize',['code_size',['../structjab__code.html#a8f6da8fa41ac7dcf5f9c69300d364182',1,'jab_code']]]
];
