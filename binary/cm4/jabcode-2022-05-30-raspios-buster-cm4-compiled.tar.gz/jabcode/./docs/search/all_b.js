var searchData=
[
  ['palette',['palette',['../structjab__encode.html#a1c0774c99fd1f7b08dbc5e5ad3d3acc2',1,'jab_encode']]],
  ['perspectivetransform',['perspectiveTransform',['../detector_8h.html#a44c04e96aa50d88100c99a9125283d25',1,'perspectiveTransform(jab_float x0, jab_float y0, jab_float x1, jab_float y1, jab_float x2, jab_float y2, jab_float x3, jab_float y3, jab_float x0p, jab_float y0p, jab_float x1p, jab_float y1p, jab_float x2p, jab_float y2p, jab_float x3p, jab_float y3p):&#160;transform.c'],['../transform_8c.html#a44c04e96aa50d88100c99a9125283d25',1,'perspectiveTransform(jab_float x0, jab_float y0, jab_float x1, jab_float y1, jab_float x2, jab_float y2, jab_float x3, jab_float y3, jab_float x0p, jab_float y0p, jab_float x1p, jab_float y1p, jab_float x2p, jab_float y2p, jab_float x3p, jab_float y3p):&#160;transform.c']]],
  ['placemastermetadatapartii',['placeMasterMetadataPartII',['../encoder_8c.html#a2ad9c7363d9a1580d61b9ad753fd9c0b',1,'encoder.c']]],
  ['preprocessimage',['preprocessImage',['../detector_8c.html#a6b3af4a8e1da475d91f47b17108df389',1,'detector.c']]]
];
