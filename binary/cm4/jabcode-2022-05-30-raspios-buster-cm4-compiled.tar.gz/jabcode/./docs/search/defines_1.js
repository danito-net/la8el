var searchData=
[
  ['fp0',['FP0',['../encoder_8h.html#a84ff1ecb322343a0de98fdfb7d485cf6',1,'encoder.h']]],
  ['fp0_5fcore_5fcolor',['FP0_CORE_COLOR',['../encoder_8h.html#ab817dbb1b2829d88afce002fd03acd92',1,'encoder.h']]]
];
