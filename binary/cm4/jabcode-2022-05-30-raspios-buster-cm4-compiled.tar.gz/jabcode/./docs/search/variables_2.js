var searchData=
[
  ['palette',['palette',['../structjab__encode.html#a1c0774c99fd1f7b08dbc5e5ad3d3acc2',1,'jab_encode']]]
];
