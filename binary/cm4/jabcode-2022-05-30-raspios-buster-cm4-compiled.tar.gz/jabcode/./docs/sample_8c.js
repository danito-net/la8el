var sample_8c =
[
    [ "SAMPLE_AREA_HEIGHT", "sample_8c.html#ab2e76e88acdc5cf00c09bf48a41ed84e", null ],
    [ "SAMPLE_AREA_WIDTH", "sample_8c.html#a5a3a4bc3d03545014760e5bcdfbe86fc", null ],
    [ "sampleCrossArea", "sample_8c.html#a74dfd2384abd2574a16bfde7fc0c2dc9", null ],
    [ "sampleSymbol", "sample_8c.html#a6586265f273ba12a50e527914dffcbfe", null ],
    [ "sampleSymbolwithNc", "sample_8c.html#a540d63013fbb4a8a247b780b08dd00be", null ]
];