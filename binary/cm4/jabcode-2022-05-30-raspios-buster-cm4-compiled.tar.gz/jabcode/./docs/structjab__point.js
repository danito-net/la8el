var structjab__point =
[
    [ "x", "structjab__point.html#a328e25e43538b6df513850af018be6a3", null ],
    [ "y", "structjab__point.html#a5a337300ef8e38825c0b0649e79a5ac8", null ]
];