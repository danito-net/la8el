var structjab__vector2d =
[
    [ "x", "structjab__vector2d.html#a400b9d06fea420480ddc8bc2443d7780", null ],
    [ "y", "structjab__vector2d.html#ade825c085e793d8156dcf2fe2d5c10dd", null ]
];