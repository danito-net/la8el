var annotated =
[
    [ "jab_alignment_pattern", "structjab__alignment__pattern.html", "structjab__alignment__pattern" ],
    [ "jab_bitmap", "structjab__bitmap.html", "structjab__bitmap" ],
    [ "jab_code", "structjab__code.html", "structjab__code" ],
    [ "jab_data", "structjab__data.html", "structjab__data" ],
    [ "jab_decoded_symbol", "structjab__decoded__symbol.html", "structjab__decoded__symbol" ],
    [ "jab_encode", "structjab__encode.html", "structjab__encode" ],
    [ "jab_finder_pattern", "structjab__finder__pattern.html", "structjab__finder__pattern" ],
    [ "jab_metadata", "structjab__metadata.html", "structjab__metadata" ],
    [ "jab_perspective_transform", "structjab__perspective__transform.html", "structjab__perspective__transform" ],
    [ "jab_point", "structjab__point.html", "structjab__point" ],
    [ "jab_symbol", "structjab__symbol.html", "structjab__symbol" ],
    [ "jab_vector2d", "structjab__vector2d.html", "structjab__vector2d" ]
];