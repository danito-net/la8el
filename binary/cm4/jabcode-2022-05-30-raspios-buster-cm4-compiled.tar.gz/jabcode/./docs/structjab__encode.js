var structjab__encode =
[
    [ "bitmap", "structjab__encode.html#a05b1992f77989186b25d79134f10aeb1", null ],
    [ "color_number", "structjab__encode.html#a02937188d37f50a15b593d9d57b76a45", null ],
    [ "master_symbol_height", "structjab__encode.html#a39b14ea93834222faa6db401558ac3c7", null ],
    [ "master_symbol_width", "structjab__encode.html#a0110b401fe25a40276d301da54390c3b", null ],
    [ "module_size", "structjab__encode.html#a6a7d4b230621476e83a1099ddb665677", null ],
    [ "palette", "structjab__encode.html#a1c0774c99fd1f7b08dbc5e5ad3d3acc2", null ],
    [ "symbol_ecc_levels", "structjab__encode.html#a6178c2e0c7876faacaaa7874568b06a0", null ],
    [ "symbol_number", "structjab__encode.html#a17d2893c3dae163426979eda11094a3b", null ],
    [ "symbol_positions", "structjab__encode.html#a77e8ea05bd53c807458538a6652a9a21", null ],
    [ "symbol_versions", "structjab__encode.html#aa59f6a3a63f7d977929d8b068315f7b9", null ],
    [ "symbols", "structjab__encode.html#ae9c2d64f535616b6e0e1b979479f6c17", null ]
];