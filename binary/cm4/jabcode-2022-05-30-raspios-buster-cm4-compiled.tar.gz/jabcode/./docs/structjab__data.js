var structjab__data =
[
    [ "data", "structjab__data.html#a16ee61c7209ef240ef3f8abecde9ba01", null ],
    [ "length", "structjab__data.html#aae8e463deec56a994f3a75e1ed859839", null ]
];