var detector_8h =
[
    [ "jab_finder_pattern", "structjab__finder__pattern.html", "structjab__finder__pattern" ],
    [ "jab_alignment_pattern", "structjab__alignment__pattern.html", "structjab__alignment__pattern" ],
    [ "jab_perspective_transform", "structjab__perspective__transform.html", "structjab__perspective__transform" ],
    [ "CROSS_AREA_WIDTH", "detector_8h.html#a37c161892980f9685d97129721771055", null ],
    [ "DIST", "detector_8h.html#adc18a5511279b56772d61c78a8e35779", null ],
    [ "MAX_FINDER_PATTERNS", "detector_8h.html#a6f98453c352a754b6b3e462e0ef018a5", null ],
    [ "MAX_MODULES", "detector_8h.html#a6cce4323245f92154efd90478606fe56", null ],
    [ "MAX_SYMBOL_COLUMNS", "detector_8h.html#ad693c8ebfb5cdc09ebf6a25be6b7cab6", null ],
    [ "MAX_SYMBOL_ROWS", "detector_8h.html#a68d995ffa8725deb9f1b3fd1cd732b11", null ],
    [ "PI", "detector_8h.html#a598a3330b3c21701223ee0ca14316eca", null ],
    [ "TEST_MODE", "detector_8h.html#ab6d58cce6e97b6b549801e696ac9f4f6", null ],
    [ "jab_detect_mode", "detector_8h.html#ae4dcb619a24b32ef9575d5837353a16f", [
      [ "QUICK_DETECT", "detector_8h.html#ae4dcb619a24b32ef9575d5837353a16fa0caa8ee76a0b088734da76aaf0f7b72d", null ],
      [ "NORMAL_DETECT", "detector_8h.html#ae4dcb619a24b32ef9575d5837353a16fa596e525fc5abb481f468aa69404c836f", null ],
      [ "INTENSIVE_DETECT", "detector_8h.html#ae4dcb619a24b32ef9575d5837353a16fa7a711fd991fb6d67106b8b4b2045bb54", null ]
    ] ],
    [ "binarizer", "detector_8h.html#a013cc09bb47faf1bbcedb9c49d17a06d", null ],
    [ "binarizerHard", "detector_8h.html#a1d1832f2f5252bc30c034627b32672e3", null ],
    [ "binarizerHist", "detector_8h.html#a8ea25a9964ffe3bd03eb7e8e2489740a", null ],
    [ "getPerspectiveTransform", "detector_8h.html#a316e58cb6a2b80e0c2a309850fde051d", null ],
    [ "perspectiveTransform", "detector_8h.html#a44c04e96aa50d88100c99a9125283d25", null ],
    [ "sampleCrossArea", "detector_8h.html#a74dfd2384abd2574a16bfde7fc0c2dc9", null ],
    [ "sampleSymbol", "detector_8h.html#a6586265f273ba12a50e527914dffcbfe", null ],
    [ "sampleSymbolwithNc", "detector_8h.html#a540d63013fbb4a8a247b780b08dd00be", null ],
    [ "warpPoints", "detector_8h.html#a2693aa030475b528827bb178db11fbcd", null ],
    [ "test_mode_bitmap", "detector_8h.html#a835a60c65da2b589499c8bf331b1889b", null ]
];