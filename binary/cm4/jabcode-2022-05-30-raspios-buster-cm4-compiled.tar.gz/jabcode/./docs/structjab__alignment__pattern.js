var structjab__alignment__pattern =
[
    [ "center", "structjab__alignment__pattern.html#a9d8ab61f5ff7698c9846797cfe4f673b", null ],
    [ "direction", "structjab__alignment__pattern.html#aaedd25f608cfb2358dbc54a495457dd7", null ],
    [ "found_count", "structjab__alignment__pattern.html#a01eec79fa4aea3803e25021b6edb059b", null ],
    [ "module_size", "structjab__alignment__pattern.html#a11ddc7d923036ffb9859dfd1121ec16d", null ],
    [ "type", "structjab__alignment__pattern.html#aca39cf1d03394308292135a72b3bbf6a", null ]
];