var structjab__finder__pattern =
[
    [ "center", "structjab__finder__pattern.html#a964af9049fbbeb7567b1b578f1415e40", null ],
    [ "direction", "structjab__finder__pattern.html#a946aa3b362f35e81c04327c1d234ee05", null ],
    [ "found_count", "structjab__finder__pattern.html#aed08c52130dc7d20d0b5cd384e6f2039", null ],
    [ "module_size", "structjab__finder__pattern.html#aef1a6b712fb975f1433d303d10a4c14f", null ],
    [ "type", "structjab__finder__pattern.html#abd2941706220bf8503415e6c3ec20abd", null ]
];