var structjab__symbol =
[
    [ "data", "structjab__symbol.html#aed4f31487c46d9d8c5737cda8a245cd2", null ],
    [ "data_map", "structjab__symbol.html#ad38bc69d5b52361cc9af95dc0f43b03b", null ],
    [ "host", "structjab__symbol.html#aaf2c8c329231f4916b555b3f8361232a", null ],
    [ "index", "structjab__symbol.html#a5e7b050d4d8f05c294067a65404d0846", null ],
    [ "matrix", "structjab__symbol.html#a385d45538eede2febe38d23b4ff87bf1", null ],
    [ "metadata", "structjab__symbol.html#a3ae341633da5a9b2373b18b9be44cf45", null ],
    [ "side_size", "structjab__symbol.html#aa59333d19adbdea20c3cc9f50c6084e1", null ],
    [ "slaves", "structjab__symbol.html#a47887434f505ec5d11dc829240bbd8f9", null ],
    [ "wcwr", "structjab__symbol.html#a8d51870adda39da39756bc1d32d5be5f", null ]
];