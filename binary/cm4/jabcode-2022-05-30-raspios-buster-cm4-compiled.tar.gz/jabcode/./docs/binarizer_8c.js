var binarizer_8c =
[
    [ "BLOCK_SIZE", "binarizer_8c.html#ad51ded0bbd705f02f73fc60c0b721ced", null ],
    [ "BLOCK_SIZE_MASK", "binarizer_8c.html#a922a001b47a0d088e36929b15dafeee8", null ],
    [ "BLOCK_SIZE_POWER", "binarizer_8c.html#a23dc1aba63aa99d4169e5b6dd225d6b8", null ],
    [ "CAP", "binarizer_8c.html#aa82eed37aee6de3e7f0011a0e639fe22", null ],
    [ "MINIMUM_DIMENSION", "binarizer_8c.html#a0c327f55930a385254ace6e6d503fc44", null ],
    [ "binarizer", "binarizer_8c.html#a013cc09bb47faf1bbcedb9c49d17a06d", null ],
    [ "binarizerHard", "binarizer_8c.html#a1d1832f2f5252bc30c034627b32672e3", null ],
    [ "binarizerHist", "binarizer_8c.html#a8ea25a9964ffe3bd03eb7e8e2489740a", null ],
    [ "calculateBlackPoints", "binarizer_8c.html#afeb3191481bfb28a7b83ee3fae5b2151", null ],
    [ "filterBinary", "binarizer_8c.html#a75d7f598fe53857b76f937e5c169d5bf", null ],
    [ "getBinaryBitmap", "binarizer_8c.html#a18bbdbfa0ea7669329a14ad5ff3012bb", null ],
    [ "getMinimumThreshold", "binarizer_8c.html#ad0a455e77ee2e7cc3adbd0d9f5dfe524", null ],
    [ "isBiTrimodal", "binarizer_8c.html#adb4a9dede1b12a5926ac6a40d487c263", null ]
];