var files =
[
    [ "binarizer.c", "binarizer_8c.html", "binarizer_8c" ],
    [ "decoder.c", "decoder_8c.html", "decoder_8c" ],
    [ "decoder.h", "decoder_8h.html", "decoder_8h" ],
    [ "detector.c", "detector_8c.html", "detector_8c" ],
    [ "detector.h", "detector_8h.html", "detector_8h" ],
    [ "encoder.c", "encoder_8c.html", "encoder_8c" ],
    [ "encoder.h", "encoder_8h.html", "encoder_8h" ],
    [ "image.c", "image_8c.html", "image_8c" ],
    [ "interleave.c", "interleave_8c.html", "interleave_8c" ],
    [ "jabcode.h", "jabcode_8h.html", "jabcode_8h" ],
    [ "ldpc.c", "ldpc_8c.html", "ldpc_8c" ],
    [ "ldpc.h", "ldpc_8h.html", "ldpc_8h" ],
    [ "mask.c", "mask_8c.html", "mask_8c" ],
    [ "pseudo_random.h", "pseudo__random_8h_source.html", null ],
    [ "sample.c", "sample_8c.html", "sample_8c" ],
    [ "transform.c", "transform_8c.html", "transform_8c" ]
];