var structjab__decoded__symbol =
[
    [ "data", "structjab__decoded__symbol.html#a0a94193fec5895ffd608ae5533b31b8b", null ],
    [ "host_index", "structjab__decoded__symbol.html#a5fdcfdbde41825e92111fd02b2b00f91", null ],
    [ "host_position", "structjab__decoded__symbol.html#a90eacc12680312473909e25d758aa63c", null ],
    [ "index", "structjab__decoded__symbol.html#a5fa55eb30f9f065e4ebe639019c33440", null ],
    [ "metadata", "structjab__decoded__symbol.html#ac6e007d6c0084d5e58b20fc3d026654e", null ],
    [ "module_size", "structjab__decoded__symbol.html#a37cdced71e04d51ab257146c0e4a99f9", null ],
    [ "palette", "structjab__decoded__symbol.html#a9fe2327fd913801d4d5658f0af4f606a", null ],
    [ "pattern_positions", "structjab__decoded__symbol.html#a6a2339deafd95e6f7215022e8e212058", null ],
    [ "side_size", "structjab__decoded__symbol.html#ab12fc683e2b6499f26950b4ad294d581", null ],
    [ "slave_metadata", "structjab__decoded__symbol.html#a9dbf94373e7a0b2e24d44ae9da4c06ee", null ]
];