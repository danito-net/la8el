var structjab__code =
[
    [ "code_size", "structjab__code.html#a8f6da8fa41ac7dcf5f9c69300d364182", null ],
    [ "col_width", "structjab__code.html#a8f8a0d656c53a6cbb276486bcc5c8a80", null ],
    [ "cols", "structjab__code.html#a1414f93a74169b70487d73a465c54157", null ],
    [ "dimension", "structjab__code.html#a04daaf524594a802de7b7ef2c973bfa0", null ],
    [ "min_x", "structjab__code.html#ab8f1f8be00f29f70907eaaf8aa3558d8", null ],
    [ "min_y", "structjab__code.html#a49a07db9df9f2153a335758f3adcb8b8", null ],
    [ "row_height", "structjab__code.html#a6e37d2d48554a5d00191d0cf910b76db", null ],
    [ "rows", "structjab__code.html#af7d4e731ac70cb686a38eeca67b5030a", null ]
];